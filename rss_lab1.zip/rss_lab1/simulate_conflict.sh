#!/usr/bin/env bash

echo "[you] Making some changes..."
python random_file_generator.py

bash bot.sh
